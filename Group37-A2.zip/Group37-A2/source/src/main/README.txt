Install Java version 17
Install JavaFX for Java 17
Run main.java
